using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UIElements;

public class GameManager : MonoBehaviour
{

    public GameObject dicePrefab;
    Vector2 newDicePos = new Vector2(9f, -4f);

    public TextMeshProUGUI textMeshProUGUI;

    int single = 0;
    int multiple = 0;
    int water = 0;
    int thunder = 0;
    int earth = 0;
    int flame = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    void FixedUpdate()
    {
        GameObject[] diceObjects = GameObject.FindGameObjectsWithTag("Dice");
        int[] updateValue = new int[6];
        int[] getCountValue = new int[6];

        foreach (GameObject diceObject in diceObjects)
        {
            Dice dice = diceObject.GetComponent<Dice>();

            if (dice != null) 
            {
                getCountValue = CountValue(dice.myTopFace);
                for (int i = 0; i < updateValue.Length; i++)
                {
                    updateValue[i] += getCountValue[i];
                }

                getCountValue = CountValue(dice.myLeftFace);
                for (int i = 0; i < updateValue.Length; i++)
                {
                    updateValue[i] += getCountValue[i];
                }

                getCountValue = CountValue(dice.myRightFace);
                for (int i = 0; i < updateValue.Length; i++)
                {
                    updateValue[i] += getCountValue[i];
                }
            }
        }

        single = updateValue[0];
        multiple = updateValue[1];
        water = updateValue[2];
        thunder = updateValue[3];
        earth = updateValue[4];
        flame = updateValue[5];

        textMeshProUGUI.text = "single: " + single + "\n" +
                               "multiple: " + multiple + "\n" +
                               "water: " + water + "\n" +
                               "thunder: " + thunder + "\n" +
                               "earth: " + earth + "\n" +
                               "flame: " + flame + "\n";
    }

    public void newDice()
    {
        if (!CheckTagAtLocation("Dice", newDicePos)){
            Instantiate(dicePrefab, newDicePos, Quaternion.identity);
        }

    }

    int[] CountValue(string diceFace)
    {
        int[] counts = new int[6];

        switch (diceFace)
        {
            case "single":
                counts[0]++;
                break;
            case "multiple":
                counts[1]++;
                break;
            case "water":
                counts[2]++;
                break;
            case "thunder":
                counts[3]++;
                break;
            case "earth":
                counts[4]++;
                break;
            case "flame":
                counts[5]++;
                break;
        }

        return counts;
    }

    bool CheckTagAtLocation(string tag, Vector2 position)
    {
        GameObject[] objectsWithTag = GameObject.FindGameObjectsWithTag(tag);

        foreach (GameObject obj in objectsWithTag)
        {
            if (Vector2.Distance(obj.transform.position, position) < 0.1f)
            {
                return true;
            }
        }

        return false;
    }
}
