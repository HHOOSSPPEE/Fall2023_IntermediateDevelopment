using System;
using UnityEngine;

public class Cultist : MonoBehaviour
{
    private float moveSpeed = 1f;
    private string[] type = new string[] { "water", "earth", "thunder", "flame" };
    SpriteRenderer spriteRenderer;

    public Sprite[] sprites;

    private float jumpForce = 0f;
    private float jumpHeight = 0.3f;
    private bool isJumping = false;

    Vector3 initialPosition;


    private enum Type
    { 
        Water,
        Earth,
        Thunder,
        Flame
    }

    Type myType;


    // Start is called before the first frame update
    void Start()
    {
        initialPosition = transform.position;

        Rigidbody2D rigidbody2D = GetComponent<Rigidbody2D>();

        myType = (Type)UnityEngine.Random.Range(0, 4);

        spriteRenderer = GetComponent<SpriteRenderer>();

        spriteRenderer.sprite = sprites[(int)myType];

        switch (myType)
        {
            case Type.Earth:

                break;

            case Type.Thunder:

                break;

        }
    }

    // Update is called once per frame
    void Update()
    {

        if (transform.position.y < initialPosition.y)
        {
            isJumping = true;
        }
        else if (transform.position.y > initialPosition.y + jumpHeight)
        {
            isJumping = false;
        }

        if (isJumping)
        {
            jumpForce = GetComponent<Rigidbody2D>().gravityScale * 2;
        }
        else
        {
            jumpForce = 0f;
        }
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = new Vector2(moveSpeed, jumpForce);
    }
}
