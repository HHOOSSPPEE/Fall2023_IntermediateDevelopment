using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class GameManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText;

    public int score;
    public static int newScore;

    public string scoretext;
    public TextMeshProUGUI mainScoreText;


    void Start()
    {
        mainScoreText.text = "" + newScore;
        DontDestroyOnLoad(gameObject);
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (score != 0)
        {
            newScore = score;
            mainScoreText.text = "" + newScore;
        }
        
    }

    public void ResetRoom()
    {
        SceneManager.LoadScene("SampleScene");

    }


    public void IncreaseScore(int number)
    {

        score += number;
        scoreText.text = " " + score;

    }

}
